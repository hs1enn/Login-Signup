export default {
  "poppins-regular": require("../assets/fonts/Poppins-Regular.ttf"),
  "poppins-bold": require("../assets/fonts/Poppins-Bold.ttf"),
  "poppins-semiBold": require("../assets/fonts/Poppins-SemiBold.ttf"),
};
